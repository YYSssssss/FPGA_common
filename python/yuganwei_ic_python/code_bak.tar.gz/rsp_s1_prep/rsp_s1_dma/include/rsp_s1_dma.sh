export rsp_s1_dma=$rsp_s1/sub/rsp_s1_dma
