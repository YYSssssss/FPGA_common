export rsp_s2_dma=$rsp_s2/sub/rsp_s2_dma
